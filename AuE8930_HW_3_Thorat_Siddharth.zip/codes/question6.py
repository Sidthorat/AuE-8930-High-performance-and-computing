import cv2
import numpy as np
import matplotlib.image as mpimg
import matplotlib.pyplot as plt

img_name = "C:/Users/siddh/OneDrive/Desktop/HPC 3/image.png"
bi_img_name = 'bilateral.png'
img = cv2.imread(img_name)
bilateral_image = cv2.bilateralFilter(img, 15, 80, 100, borderType=cv2.BORDER_CONSTANT)

cv2.imshow('test_image', img)
cv2.imshow(bi_img_name, bilateral_image)
cv2.imwrite(bi_img_name, bilateral_image) 
imag = mpimg.imread(img_name)
image = mpimg.imread(bi_img_name)
print(img)
print(image)
cv2.waitKey(0)
