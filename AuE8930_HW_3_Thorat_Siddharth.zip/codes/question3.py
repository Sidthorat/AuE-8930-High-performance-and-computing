class ListNode:
    def __init__(self, val=0, next=0):
        self.data = val
        self.next = next

class LinkedList:
    def __init__(self):
        self.head = None

    def push(self, new_node_data):
        new_node = ListNode(new_node_data)
        new_node.next = self.head
        self.head = new_node

    def addTwoLists(self, list1, list2):
        prev_node = None
        temp_node = None
        carry = 0

        while(list1 != None or list2 != None):
            if list1 is None:
                fdata = 0
            else:
                fdata = list1.data

            if list2 is None:
                sdata = 0
            else:
                sdata = list2.data

            Sum = carry + fdata + sdata

            if Sum >= 10:
                carry = 1
            else:
                carry = 0

            if Sum >= 10:
                Sum = Sum % 10

            temp_node = ListNode(Sum)

            if self.head is None:
                self.head = temp_node
            else:
                prev_node.next = temp_node

            prev_node = temp_node

            if list1 is not None:
                list1 = list1.next
            if list2 is not None:
                list2 = list2.next

        if carry > 0:
            temp_node.next = ListNode(carry)

    # Utility function to print the linked LinkedList
    def printList(self):
        temp_node = self.head
        while(temp_node):
            print(temp_node.data)
            temp_node = temp_node.next

# Driver code
first = LinkedList()
second = LinkedList()

# Create first list
first.push(2)
first.push(4)
first.push(3)

print ("First List is ")
first.printList()

# Create second list
second.push(5)
second.push(6)
second.push(4)
print ("\nSecond List is ")
second.printList()

# Add the two lists and see result
res = LinkedList()
res.addTwoLists(first.head, second.head)
print ("\nResultant list is ")
res.printList()

#Time and space complexity are O(n) i.e. constant time
