class Solution(object):
   def lengthOfLongestSubstring(self, s):
      a, b, result = 0, 0, 0
      d = {}
      while b < len(s):
         if s[b] in d and a <= d[s[b]]:
            a = d[s[b]] + 1
            result = max(result, (b - a + 1))
            b -= 1
         else:
            result = max(result, (b - a + 1))
            d[s[b]] = b
         b += 1
      return result


ob1 = Solution()
inp=input("Enter String :")
print(ob1.lengthOfLongestSubstring(inp))
