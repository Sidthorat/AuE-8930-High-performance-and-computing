# -*- coding: utf-8 -*-
"""
Created on xun Nov 13 11:01:58 2022

@author: xiddh
"""
# re — Regular expression operations
import re
def solution(x: str) -> bool:
    if (x == ''):
        return True
    elif not ((x.count('(') - x.count(')')) == 0 and (x.count('[') - x.count(']')) == 0 and (x.count('{') - x.count('}')) == 0):
        return False
    else:
        sol = [re.search(pattern, x)
                   for pattern in ['\((.)*\)', '\[(.)*\]', '\{(.)*\}']]
        sol = ['' if sol[i] is None else sol[i].group()[1:-1]
                   for i in range(len(sol))]
        return solution(sol[0]) and solution(sol[1]) and solution(sol[2])
if __name__ == '__main__':
    print(solution('([]){'))
    print(solution('[]'))
