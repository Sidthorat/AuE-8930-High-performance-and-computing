import cv2 
  
# Read the image. 
img = cv2.imread('you_image.jpg') 
  
# Apply bilateral filter

  
# Save the output. 
cv2.imwrite('bilateral.jpg', bilateral) 
