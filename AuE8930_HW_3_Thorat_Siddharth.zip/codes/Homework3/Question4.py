class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
