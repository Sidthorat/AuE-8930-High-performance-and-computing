def solution(input_list, number):
    result = dict()
    for index, item in enumerate(input_list):
        b = number - item
        if b in result:
            return[result[b], index]

        result[item] = index


print(solution([0, 21, 78, 19, 90, 13], 21))
print(solution([0, 21, 78, 19, 90, 13], 25))
